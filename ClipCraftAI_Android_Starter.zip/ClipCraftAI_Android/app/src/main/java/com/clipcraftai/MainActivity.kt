package com.clipcraftai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B2940)
private val Accent = Color(0xFF8B7CFF)
private val Mint = Color(0xFF70D6B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipCraftApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClipCraftApp() {
    var page by remember { mutableStateOf("home") }
    var videoLink by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var clips by remember { mutableStateOf(listOf<String>()) }
    var storyMode by remember { mutableStateOf("topic") }
    var status by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> selectedVideo = uri }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Mint,
            background = Ink,
            surface = Panel
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("CLIPCRAFT AI", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("Your content studio", fontSize = 11.sp, color = Color.LightGray)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Ink, titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(
                        selected = page == "home", onClick = { page = "home" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = page == "clipping", onClick = { page = "clipping" },
                        icon = { Icon(Icons.Default.ContentCut, null) }, label = { Text("Clipping") }
                    )
                    NavigationBarItem(
                        selected = page == "stories", onClick = { page = "stories" },
                        icon = { Icon(Icons.Default.SmartToy, null) }, label = { Text("Stories") }
                    )
                }
            }
        ) { padding ->
            when (page) {
                "clipping" -> ClippingScreen(
                    modifier = Modifier.padding(padding),
                    link = videoLink, onLink = { videoLink = it },
                    selectedVideo = selectedVideo,
                    onPick = { picker.launch(arrayOf("video/*")) },
                    clips = clips, onGenerate = {
                        clips = (1..5).map { "Short $it — draft ready for editing" }
                        status = "Demo drafts created. Connect the video-processing backend to generate real clips."
                    },
                    onEdit = { i, value -> clips = clips.toMutableList().also { it[i] = value } },
                    status = status,
                    onPublish = { status = "Publishing needs connected YouTube and Instagram accounts plus approved platform API access." }
                )
                "stories" -> StoriesScreen(
                    modifier = Modifier.padding(padding),
                    topic = topic, onTopic = { topic = it },
                    mode = storyMode, onMode = { storyMode = it },
                    status = status,
                    onGenerate = {
                        status = if (storyMode == "topic" && topic.isBlank()) {
                            "Add a story topic first."
                        } else {
                            "Story brief created in demo mode. Connect a story-generation, Roblox-visual, subtitle and text-to-speech backend for a real video."
                        }
                    },
                    onPublish = { status = "Publishing needs connected YouTube and Instagram accounts plus approved platform API access." }
                )
                else -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onClipping = { page = "clipping" },
                    onStories = { page = "stories" }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(modifier: Modifier, onClipping: () -> Unit, onStories: () -> Unit) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Make once. Create more.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Choose what you want to create today.", color = Color.LightGray)
        }
        item {
            StudioCard(
                title = "CLIPPING",
                subtitle = "Turn a long video into 4–5 vertical shorts.",
                icon = Icons.Default.ContentCut,
                tint = Accent,
                onClick = onClipping
            )
        }
        item {
            StudioCard(
                title = "ROBLOX STORIES",
                subtitle = "Create narrated stories with recurring characters.",
                icon = Icons.Default.SportsEsports,
                tint = Mint,
                onClick = onStories
            )
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("PUBLISHING HUB", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayCircle, null, tint = Color.Red)
                        Spacer(Modifier.width(8.dp))
                        Text("YouTube", color = Color.White)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.CameraAlt, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Instagram", color = Color.White)
                    }
                    Text(
                        "You will review every video before choosing where to publish.",
                        color = Color.LightGray, fontSize = 12.sp
                    )
                }
            }
        }
        item {
            Text(
                "Prototype build: generation and publishing are not connected yet. Your drafts and workflow can be wired to real services next.",
                color = Color.Gray, fontSize = 12.sp
            )
        }
    }
}

@Composable
fun StudioCard(
    title: String, subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color, onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = tint.copy(alpha = .18f), shape = RoundedCornerShape(16.dp)) {
                Icon(icon, null, tint = tint, modifier = Modifier.padding(14.dp).size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Color.LightGray, fontSize = 13.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.White)
        }
    }
}

@Composable
fun ClippingScreen(
    modifier: Modifier, link: String, onLink: (String) -> Unit,
    selectedVideo: Uri?, onPick: () -> Unit,
    clips: List<String>, onGenerate: () -> Unit,
    onEdit: (Int, String) -> Unit, status: String, onPublish: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Clipping studio", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Add a video link or choose a video file.", color = Color.LightGray)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = link, onValueChange = onLink,
            label = { Text("Paste video link") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VideoLibrary, null)
            Spacer(Modifier.width(8.dp))
            Text(if (selectedVideo == null) "Choose video from phone" else "Video selected")
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onGenerate, modifier = Modifier.fillMaxWidth(),
            enabled = link.isNotBlank() || selectedVideo != null
        ) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text("Generate 4–5 shorts")
        }
        Spacer(Modifier.height(10.dp))
        if (status.isNotBlank()) Text(status, color = Mint, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text("YOUR SHORTS", color = Color.White, fontWeight = FontWeight.Bold)
        if (clips.isEmpty()) {
            Text("Your generated shorts will appear here. Each one will have its own edit screen.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(clips.indices.toList()) { index ->
                    var caption by remember(clips[index]) { mutableStateOf(clips[index]) }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("SHORT ${index + 1}", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            OutlinedTextField(
                                value = caption, onValueChange = {
                                    caption = it; onEdit(index, it)
                                },
                                label = { Text("Edit title / caption") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
            Button(onClick = onPublish, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Publish, null)
                Spacer(Modifier.width(8.dp))
                Text("Continue to publishing")
            }
        }
    }
}

@Composable
fun StoriesScreen(
    modifier: Modifier, topic: String, onTopic: (String) -> Unit,
    mode: String, onMode: (String) -> Unit, status: String,
    onGenerate: () -> Unit, onPublish: () -> Unit
) {
    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Roblox story studio", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Keep your cast, names and narration style consistent across episodes.", color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == "topic", onClick = { onMode("topic") }, label = { Text("My topic") })
            FilterChip(selected = mode == "auto", onClick = { onMode("auto") }, label = { Text("AI idea") })
        }
        if (mode == "topic") {
            OutlinedTextField(
                value = topic, onValueChange = onTopic,
                label = { Text("What should the story be about?") },
                modifier = Modifier.fillMaxWidth(), minLines = 3
            )
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text(
                    "The AI will suggest an original story idea when the story-generation service is connected.",
                    color = Color.LightGray, modifier = Modifier.padding(14.dp)
                )
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("CHARACTER & VOICE BIBLE", color = Mint, fontWeight = FontWeight.Bold)
                Text("Save character names, appearance descriptions and one licensed synthetic voice preset here. Reuse them for every episode.", color = Color.LightGray, fontSize = 13.sp)
            }
        }
        Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text("Create story video")
        }
        if (status.isNotBlank()) Text(status, color = Mint, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onPublish, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Publish, null)
            Spacer(Modifier.width(8.dp))
            Text("Continue to publishing")
        }
    }
}
