# ClipCraft AI — Android starter

This is a native Android Studio starter app named **ClipCraft AI**. It contains the first UI flow for:
- Clipping: paste a source link or select a local video, create a draft list of 5 shorts, and edit each draft caption.
- Roblox Stories: choose a user-provided topic or AI-idea mode, with a place for a reusable character/voice bible.
- Publishing hub: a review-before-publish handoff for YouTube and Instagram.

## Important: what is and isn't implemented

This is a working **UI prototype**, not a finished AI video service. The Generate buttons currently create demo states/messages. Real functionality needs a secure backend:
1. Video ingestion and rights/permission checks for source URLs.
2. Speech-to-text, highlight detection, vertical reframing, subtitle rendering, and video export.
3. Roblox-style scene generation or licensed assets, story writing, text-to-speech, and a persistent character/voice bible.
4. User authentication and secure storage for platform tokens.
5. YouTube Data API upload integration and Instagram Graph API publishing for eligible professional accounts. Platform access, permissions, review, account type and current policies apply. Do not put API secrets in the Android app.

The app intentionally asks the user to review and approve content before publishing. It does not auto-post anything in this starter.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `ClipCraftAI_Android` folder in Android Studio.
3. Let Gradle sync.
4. Run the `app` configuration on an Android phone or emulator.

Requirements: Android Studio with JDK 17 and Android SDK 35 installed. If Android Studio offers a Gradle/plugin upgrade, accept compatible stable versions.

## Suggested backend API contract

Implement these endpoints on a server (not inside the Android APK):
- `POST /v1/clips/jobs` — source URL or uploaded media; returns job ID.
- `GET /v1/jobs/{id}` — processing progress and output list.
- `PATCH /v1/videos/{id}` — edit title, caption, subtitle style and trim points.
- `POST /v1/stories/jobs` — topic or auto-idea mode plus character-bible ID.
- `GET /v1/character-bibles` / `POST /v1/character-bibles` — persistent recurring cast and licensed voice preset.
- `POST /v1/publish/youtube` and `POST /v1/publish/instagram` — publish only after explicit confirmation.

Use OAuth on the backend and encrypt tokens at rest. Never ask users to paste passwords or expose API keys in the app.
